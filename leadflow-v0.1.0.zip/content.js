// `var` deliberately permits a fresh injection after the extension itself has
// been reloaded while the Instagram tab stayed open.
var collector = globalThis.__leadflowCollector || null;

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "leadflow:ping") {
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "leadflow:collector-start") {
    startCollector(message.payload);
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "leadflow:browser-collection-start") {
    startBrowserCollection(message.payload);
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "leadflow:collector-stop") {
    stopCollector("Stopped by user", "stopped");
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "leadflow:collector-pause") {
    pauseCollector();
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "leadflow:collector-resume") {
    resumeCollector();
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "leadflow:scan-profile") {
    sendResponse({ profile: scanProfile() });
  }
});

function startCollector(payload) {
  stopCollector();
  collector = {
    ...payload,
    emptyCycles: 0,
    seen: new Set(),
    timer: null
  };
  globalThis.__leadflowCollector = collector;
  collectOnce();
}

function pauseCollector() {
  if (!collector || collector.paused) return;
  if (collector.timer) clearTimeout(collector.timer);
  collector.timer = null;
  collector.paused = true;
  chrome.runtime.sendMessage({ type: "leadflow:collector-status", payload: { taskId: collector.taskId, status: "paused", reason: "Paused by user" } });
}

function resumeCollector() {
  if (!collector || !collector.paused) return;
  collector.paused = false;
  chrome.runtime.sendMessage({ type: "leadflow:collector-status", payload: { taskId: collector.taskId, status: "running", reason: null } });
  collectOnce();
}

async function startBrowserCollection(payload) {
  stopCollector();
  const trigger = findListTrigger(payload.listType);
  if (!trigger) {
    chrome.runtime.sendMessage({ type: "leadflow:collector-status", payload: { taskId: payload.taskId, status: "paused", reason: `Could not find the ${payload.listType} control on this profile page.` } });
    return;
  }
  trigger.click();
  const dialog = await waitForDialog();
  if (!dialog) {
    chrome.runtime.sendMessage({ type: "leadflow:collector-status", payload: { taskId: payload.taskId, status: "paused", reason: "Instagram did not open the list dialog. Refresh the profile and try again." } });
    return;
  }
  startCollector(payload);
}

function findListTrigger(listType) {
  const pathPart = listType === "followers" ? "/followers" : "/following";
  const link = [...document.querySelectorAll("a[href]")].find((element) => element.getAttribute("href")?.includes(pathPart));
  if (link) return link;

  // New Instagram profile pages use <a href="#" role="link"> for their
  // profile stats. Search the full document because the profile shell does not
  // consistently use a <main> or <header> ancestor across experiments.
  const directLabels = listType === "followers"
    ? ["followers", "粉丝", "フォロワー", "팔로워", "seguidores", "abonnés", "follower"]
    : ["following", "关注", "フォロー中", "팔로잉", "siguiendo", "abonnements", "gefolgt"];
  const directStat = [...document.querySelectorAll('a[role="link"], [role="link"]')]
    .find((element) => {
      const text = (element.textContent || "").replace(/\s+/g, "").trim();
      return text.length <= 32 && /[0-9０-９]/.test(text) && directLabels.some((label) => text.toLowerCase().endsWith(label.toLowerCase()));
    });
  if (directStat) return directStat;

  // Fallback for older layouts where the statistic is nested under another
  // interactive element. The numeric requirement excludes the follow button.
  const profileRoot = document.querySelector("main") || document;
  const labels = listType === "followers"
    ? ["followers", "粉丝", "フォロワー", "팔로워", "seguidores", "abonnés", "follower"]
    : ["following", "关注", "フォロー中", "팔로잉", "siguiendo", "abonnements", "gefolgt"];
  const countPrefix = "[0-9０-９][0-9０-９.,，万千KkMmB b ]*";
  const pattern = new RegExp(`^${countPrefix}(${labels.join("|")})$`, "i");
  const stat = [...profileRoot.querySelectorAll('a[role="link"], a, button, [role=button], span, div')]
    .find((element) => pattern.test((element.textContent || "").trim()));
  return stat?.closest("a, button, [role=button]") || null;
}

function waitForDialog(timeoutMs = 8000) {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    const timer = setInterval(() => {
      const dialog = document.querySelector('[role="dialog"]');
      if (dialog) { clearInterval(timer); resolve(dialog); }
      else if (Date.now() - startedAt >= timeoutMs) { clearInterval(timer); resolve(null); }
    }, 200);
  });
}

function stopCollector(reason, status = "paused") {
  if (!collector) return;
  if (collector.timer) clearTimeout(collector.timer);
  const finished = collector;
  collector = null;
  globalThis.__leadflowCollector = null;
  if (reason) {
    chrome.runtime.sendMessage({
      type: "leadflow:collector-status",
      payload: { taskId: finished.taskId, status, reason }
    });
  }
}

function collectOnce() {
  if (!collector || collector.paused) return;
  const records = collectVisibleProfiles();
  const fresh = records.filter((record) => !collector.seen.has(record.username));
  fresh.forEach((record) => collector.seen.add(record.username));

  if (fresh.length) {
    collector.emptyCycles = 0;
    chrome.runtime.sendMessage({
      type: "leadflow:collector-batch",
      payload: { taskId: collector.taskId, records: fresh, sourceProfile: collector.sourceProfile }
    });
  } else {
    collector.emptyCycles += 1;
  }

  if (collector.seen.size >= collector.limit) {
    stopCollector("Reached the selected collection limit", "completed");
    return;
  }

  const container = getScrollableList();
  if (!container) {
    stopCollector("Instagram list dialog was closed. Collection interrupted; reopen it and start a new task.");
    return;
  }

  if (collector.emptyCycles >= 4) {
    stopCollector("No new visible profiles were loaded; the list may be complete or unavailable", "completed");
    return;
  }

  container.scrollTop += Math.max(360, Math.round(container.clientHeight * 0.75));
  collector.timer = setTimeout(collectOnce, Math.max(1500, collector.delayMs));
}

function getScrollableList() {
  const dialog = document.querySelector('[role="dialog"]');
  if (!dialog) return null;
  const candidates = [dialog, ...dialog.querySelectorAll("div")];
  return candidates.find((element) => {
    const style = getComputedStyle(element);
    return element.scrollHeight > element.clientHeight + 40 &&
      ["auto", "scroll"].includes(style.overflowY);
  }) || null;
}

function collectVisibleProfiles() {
  const dialog = document.querySelector('[role="dialog"]');
  if (!dialog) return [];
  const links = [...dialog.querySelectorAll('a[href^="/"]')];
  const unique = new Map();
  for (const link of links) {
    const username = normalizeUsername(link.getAttribute("href"));
    if (!username || username === "explore" || username === "accounts") continue;
    const row = link.closest("div[role], li") || link.parentElement?.parentElement || link;
    const text = (row?.innerText || "").trim().split("\n").filter(Boolean);
    unique.set(username, {
      username,
      displayName: text.find((item) => item !== username) || "",
      profileUrl: `https://www.instagram.com/${username}/`,
      avatarUrl: row?.querySelector("img")?.currentSrc || "",
      isVerified: Boolean(row?.querySelector('svg[aria-label*="Verified"], svg[title*="Verified"]'))
    });
  }
  return [...unique.values()];
}

function normalizeUsername(href) {
  if (!href) return null;
  const match = href.match(/^\/([^/?#]+)\/?/);
  if (!match || /^(p|reel|stories|direct|accounts|explore)$/i.test(match[1])) return null;
  return match[1];
}

function scanProfile() {
  const username = normalizeUsername(location.pathname) || "";
  const header = document.querySelector("main header") || document.querySelector("header");
  return {
    username,
    profileUrl: location.href.split("?")[0],
    displayName: header?.querySelector("h1, h2")?.textContent?.trim() || ""
  };
}
